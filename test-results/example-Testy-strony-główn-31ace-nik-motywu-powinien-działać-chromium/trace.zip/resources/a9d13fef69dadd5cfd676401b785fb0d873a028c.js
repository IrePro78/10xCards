(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__64b33e3d._.css",
  "static/chunks/node_modules_67330ae8._.js",
  "static/chunks/_907f4065._.js"
],
    source: "dynamic"
});
